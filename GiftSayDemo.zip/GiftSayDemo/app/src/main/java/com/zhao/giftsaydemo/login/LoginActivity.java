package com.zhao.giftsaydemo.login;

import com.zhao.giftsaydemo.R;
import com.zhao.giftsaydemo.annotation.BindContent;
import com.zhao.giftsaydemo.base.BaseActivity;

/**
 * Created by 华哥哥 on 16/5/30.
 */
@BindContent(R.layout.activity_login)
public class LoginActivity extends BaseActivity{
    @Override
    public void initData() {

    }
}
